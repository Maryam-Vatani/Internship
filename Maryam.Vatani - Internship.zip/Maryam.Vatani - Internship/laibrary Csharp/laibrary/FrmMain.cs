﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Globalization;


namespace library
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }


        private void ثبتوویرایشکتابToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new frminsertbook().ShowDialog();
        }


        private void ثبتوویرایشاعضاءToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            new FrmMember().ShowDialog();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
          
            new FrmLoad().Close();
            
            label2.Text = Datenow(DateTime.Now);
    
            notifyIcon1.Icon = this.Icon;
            notifyIcon1.Visible = true;
            notifyIcon1.ShowBalloonTip(3000, "خوش آمدید", "مدیریت کتابخانه", ToolTipIcon.Info);
            notifyIcon1.Text = "نرام افزار مدیریت کتابخانه";
      
        }
        string shamsi(DateTime t1)
        {
            PersianCalendar pc = new PersianCalendar();
            return pc.GetHour(t1).ToString() + "." + pc.GetMinute(t1) + "." + pc.GetSecond(t1).ToString();
        }
        string Datenow(DateTime today)
        {
            PersianCalendar pc = new PersianCalendar();
            return ("  امروز: ")+pc.GetYear(today).ToString("0000") + pc.GetMonth(today).ToString("/00") + pc.GetDayOfMonth(today).ToString("/00");
            
        }

        private void لیستاعضاءToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FrmMeberList().ShowDialog();
        }

        private void لیستکتبموجودToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FrmBookList().ShowDialog();
        }

        private void buttonX1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void elButton1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ثبتامانتToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FrmAmanat().ShowDialog();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            new FrmBookList().ShowDialog();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            new frminsertbook().ShowDialog();
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            new FrmMember().ShowDialog();
        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            new FrmMeberList().ShowDialog();
        }

        private void toolStripMenuItem10_Click(object sender, EventArgs e)
        {
            new FrmAmanat().ShowDialog();
        }

        private void ثبتکاربرجدیدToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (!FrmUserPass.Adminuser)
            {
                MessageBox.Show("محدودیت دسترسی");
                return;
            }
            new FrmUser().ShowDialog();
        }

        private void notifyIcon1_MouseClick(object sender, MouseEventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
        }

        private void aboutToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("نرم افزار مدیریت کتابخانه\r\nپروژه پایانی کارشناسی مهندسی کامپیوتر\r\nبرنامه نویس: مریم وطنی\r\nاستاد راهنما: دکتر سید علی رضوی ابراهیمی\r\nدانشگاه پیام نور - واحد ری");
        }

        private void elButton3_Click(object sender, EventArgs e)
        {
            if (!FrmUserPass.Adminuser)
            {
                MessageBox.Show("محدودیت دسترسی");
                return;
            }
            new frminsertbook().ShowDialog();
        }

        private void elButton4_Click(object sender, EventArgs e)
        {
            new FrmAmanat().ShowDialog();
        }

        private void elButton2_Click(object sender, EventArgs e)
        {
            if (!FrmUserPass.Adminuser)
            {
                MessageBox.Show("محدودیت دسترسی");
                return;
            }
            new frminsertbook().ShowDialog();
        }

        private void elButton1_Click_2(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void elButton5_Click(object sender, EventArgs e)
        {
            if (!FrmUserPass.Adminuser)
            {
                MessageBox.Show("محدودیت دسترسی");
                return;
            }
            new FrmUser().ShowDialog();
        }


        private void elButton2_Click_3(object sender, EventArgs e)
        {
            new frminsertbook().ShowDialog();
        }

        private void elButton3_Click_1(object sender, EventArgs e)
        {
            new FrmMember().ShowDialog();
        }

        private void elButton4_Click_1(object sender, EventArgs e)
        {
            new FrmAmanat().ShowDialog();
        }

        private void elButton5_Click_1(object sender, EventArgs e)
        {
            new FrmUser().ShowDialog();
        }

        private void elButton3_Click_2(object sender, EventArgs e)
        {
            new FrmMember().ShowDialog();
        }

        private void elButton4_Click_2(object sender, EventArgs e)
        {
            new FrmAmanat().ShowDialog();
        }

        private void elButton5_Click_2(object sender, EventArgs e)
        {
            new FrmUser().ShowDialog();
        }

        private void elButton4_Click_3(object sender, EventArgs e)
        {
            new FrmAmanat().ShowDialog();
        }

        private void elButton3_Click_3(object sender, EventArgs e)
        {
            new FrmMember().ShowDialog();
        }

        private void elButton5_Click_3(object sender, EventArgs e)
        {
            new FrmUser().ShowDialog();
        }

        private void امانتToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FrmAmanatNew().ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = shamsi(DateTime.Now);
        }

        private void elRichPanel1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
 

