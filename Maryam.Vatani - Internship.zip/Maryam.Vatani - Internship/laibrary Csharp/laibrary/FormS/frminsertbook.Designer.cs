﻿namespace library
{
    partial class frminsertbook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.حذفToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.بروزرسانیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.خروجToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtAuthor = new System.Windows.Forms.TextBox();
            this.txtISBN = new System.Windows.Forms.TextBox();
            this.txtpublisher = new System.Windows.Forms.TextBox();
            this.txtPublishyear = new System.Windows.Forms.TextBox();
            this.txtprice = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtradebandi = new System.Windows.Forms.TextBox();
            this.BTedit = new System.Windows.Forms.Button();
            this.bt4delete = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.radioBkAuthor = new System.Windows.Forms.RadioButton();
            this.radioBkName = new System.Windows.Forms.RadioButton();
            this.button4 = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.radioBkCode = new System.Windows.Forms.RadioButton();
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            this.elRichPanel1 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.elRichPanel2 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.txtTedad = new System.Windows.Forms.TextBox();
            this.txtBookId = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.btback = new DevComponents.DotNetBar.ButtonX();
            this.btExit = new DevComponents.DotNetBar.ButtonX();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.bookId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.author = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.isbn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.publisher = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.publishyear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.radebandi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tedad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label9 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).BeginInit();
            this.elRichPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel2)).BeginInit();
            this.elRichPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(23, 45);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "افزودن";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.حذفToolStripMenuItem,
            this.بروزرسانیToolStripMenuItem,
            this.خروجToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(111, 70);
            // 
            // حذفToolStripMenuItem
            // 
            this.حذفToolStripMenuItem.Name = "حذفToolStripMenuItem";
            this.حذفToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.حذفToolStripMenuItem.Text = "حذف";
            this.حذفToolStripMenuItem.Click += new System.EventHandler(this.حذفToolStripMenuItem_Click);
            // 
            // بروزرسانیToolStripMenuItem
            // 
            this.بروزرسانیToolStripMenuItem.Name = "بروزرسانیToolStripMenuItem";
            this.بروزرسانیToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.بروزرسانیToolStripMenuItem.Text = "ویرایش";
            this.بروزرسانیToolStripMenuItem.Click += new System.EventHandler(this.بروزرسانیToolStripMenuItem_Click);
            // 
            // خروجToolStripMenuItem
            // 
            this.خروجToolStripMenuItem.Name = "خروجToolStripMenuItem";
            this.خروجToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.خروجToolStripMenuItem.Text = "خروج";
            this.خروجToolStripMenuItem.Click += new System.EventHandler(this.خروجToolStripMenuItem_Click);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(134, 67);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 21);
            this.txtName.TabIndex = 1;
            // 
            // txtAuthor
            // 
            this.txtAuthor.Location = new System.Drawing.Point(134, 99);
            this.txtAuthor.Name = "txtAuthor";
            this.txtAuthor.Size = new System.Drawing.Size(100, 21);
            this.txtAuthor.TabIndex = 2;
            // 
            // txtISBN
            // 
            this.txtISBN.Location = new System.Drawing.Point(134, 130);
            this.txtISBN.Name = "txtISBN";
            this.txtISBN.Size = new System.Drawing.Size(100, 21);
            this.txtISBN.TabIndex = 3;
            // 
            // txtpublisher
            // 
            this.txtpublisher.Location = new System.Drawing.Point(134, 162);
            this.txtpublisher.Name = "txtpublisher";
            this.txtpublisher.Size = new System.Drawing.Size(100, 21);
            this.txtpublisher.TabIndex = 4;
            // 
            // txtPublishyear
            // 
            this.txtPublishyear.Location = new System.Drawing.Point(134, 194);
            this.txtPublishyear.Name = "txtPublishyear";
            this.txtPublishyear.Size = new System.Drawing.Size(100, 21);
            this.txtPublishyear.TabIndex = 5;
            // 
            // txtprice
            // 
            this.txtprice.Location = new System.Drawing.Point(134, 225);
            this.txtprice.Name = "txtprice";
            this.txtprice.Size = new System.Drawing.Size(100, 21);
            this.txtprice.TabIndex = 6;
            this.txtprice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtprice_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Location = new System.Drawing.Point(282, 103);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "نویسنده:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(292, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 13);
            this.label3.TabIndex = 22;
            this.label3.Text = "شابک:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(294, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 22;
            this.label1.Text = "عنوان:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(298, 168);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 21;
            this.label2.Text = "ناشر:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(249, 261);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "رده بندی کنگره :";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Location = new System.Drawing.Point(264, 198);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 13);
            this.label6.TabIndex = 20;
            this.label6.Text = "سال انتشار: ";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Location = new System.Drawing.Point(294, 230);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 13);
            this.label8.TabIndex = 19;
            this.label8.Text = "قیمت:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtradebandi
            // 
            this.txtradebandi.Location = new System.Drawing.Point(134, 257);
            this.txtradebandi.Name = "txtradebandi";
            this.txtradebandi.Size = new System.Drawing.Size(100, 21);
            this.txtradebandi.TabIndex = 7;
            // 
            // BTedit
            // 
            this.BTedit.Enabled = false;
            this.BTedit.Location = new System.Drawing.Point(23, 108);
            this.BTedit.Name = "BTedit";
            this.BTedit.Size = new System.Drawing.Size(75, 23);
            this.BTedit.TabIndex = 9;
            this.BTedit.Text = "ثبت تغییرات";
            this.BTedit.UseVisualStyleBackColor = true;
            this.BTedit.Click += new System.EventHandler(this.button3_Click);
            // 
            // bt4delete
            // 
            this.bt4delete.Location = new System.Drawing.Point(23, 171);
            this.bt4delete.Name = "bt4delete";
            this.bt4delete.Size = new System.Drawing.Size(75, 23);
            this.bt4delete.TabIndex = 10;
            this.bt4delete.Text = "حذف";
            this.bt4delete.UseVisualStyleBackColor = true;
            this.bt4delete.Click += new System.EventHandler(this.bt4delete_Click);
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(36, 59);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(176, 21);
            this.textBox1.TabIndex = 15;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown);
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // radioBkAuthor
            // 
            this.radioBkAuthor.AutoSize = true;
            this.radioBkAuthor.CausesValidation = false;
            this.radioBkAuthor.Location = new System.Drawing.Point(230, 60);
            this.radioBkAuthor.Name = "radioBkAuthor";
            this.radioBkAuthor.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioBkAuthor.Size = new System.Drawing.Size(79, 17);
            this.radioBkAuthor.TabIndex = 14;
            this.radioBkAuthor.TabStop = true;
            this.radioBkAuthor.Text = "نام نویسنده";
            this.radioBkAuthor.UseVisualStyleBackColor = true;
            this.radioBkAuthor.CheckedChanged += new System.EventHandler(this.radioBkAuthor_CheckedChanged);
            // 
            // radioBkName
            // 
            this.radioBkName.AutoSize = true;
            this.radioBkName.Location = new System.Drawing.Point(244, 35);
            this.radioBkName.Name = "radioBkName";
            this.radioBkName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioBkName.Size = new System.Drawing.Size(65, 17);
            this.radioBkName.TabIndex = 13;
            this.radioBkName.TabStop = true;
            this.radioBkName.Text = "نام کتاب ";
            this.radioBkName.UseVisualStyleBackColor = true;
            this.radioBkName.CheckedChanged += new System.EventHandler(this.radioBkName_CheckedChanged);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(23, 108);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 11;
            this.button4.Text = "ویرایش";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // radioBkCode
            // 
            this.radioBkCode.AutoSize = true;
            this.radioBkCode.BackColor = System.Drawing.Color.Transparent;
            this.radioBkCode.Location = new System.Drawing.Point(249, 85);
            this.radioBkCode.Name = "radioBkCode";
            this.radioBkCode.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioBkCode.Size = new System.Drawing.Size(60, 17);
            this.radioBkCode.TabIndex = 12;
            this.radioBkCode.TabStop = true;
            this.radioBkCode.Text = "کد کتاب";
            this.radioBkCode.UseVisualStyleBackColor = false;
            this.radioBkCode.CheckedChanged += new System.EventHandler(this.radioBkCode_CheckedChanged);
            // 
            // kFormManager1
            // 
            this.kFormManager1.BackgroundImageStyle.Alpha = 100;
            this.kFormManager1.BackgroundImageStyle.ImageEffect = Klik.Windows.Forms.v1.Common.ImageEffect.Mirror;
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.FormOffice2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.kFormManager1.MainContainer = this;
            this.kFormManager1.ToolStripOffice2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            // 
            // elRichPanel1
            // 
            this.elRichPanel1.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel1.ContainerStyle.BorderStyle.SmoothingMode = Klik.Windows.Forms.v1.Common.SmoothingModes.AntiAlias;
            this.elRichPanel1.ContainerStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elRichPanel1.Controls.Add(this.radioBkCode);
            this.elRichPanel1.Controls.Add(this.radioBkAuthor);
            this.elRichPanel1.Controls.Add(this.radioBkName);
            this.elRichPanel1.Controls.Add(this.textBox1);
            this.elRichPanel1.Expanded = true;
            this.elRichPanel1.FooterStyle.BackgroundStyle.GradientAngle = 0F;
            this.elRichPanel1.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel1.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.FooterStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.elRichPanel1.FooterStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elRichPanel1.FooterStyle.TextStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(83)))), ((int)(((byte)(92)))));
            this.elRichPanel1.HeaderStyle.BackgroundImageStyle.FilterColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.elRichPanel1.HeaderStyle.BackgroundStyle.SolidColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.elRichPanel1.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.HeaderStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.elRichPanel1.HeaderStyle.ForegroundImageStyle.TransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.elRichPanel1.HeaderStyle.Height = 24;
            this.elRichPanel1.HeaderStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elRichPanel1.HeaderStyle.TextStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(83)))), ((int)(((byte)(92)))));
            this.elRichPanel1.HeaderStyle.TextStyle.Text = "منــوی جستجــو";
            this.elRichPanel1.Location = new System.Drawing.Point(545, 358);
            this.elRichPanel1.Name = "elRichPanel1";
            this.elRichPanel1.Padding = new System.Windows.Forms.Padding(1, 24, 1, 16);
            this.elRichPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.elRichPanel1.Size = new System.Drawing.Size(341, 136);
            this.elRichPanel1.TabIndex = 65;
            // 
            // elRichPanel2
            // 
            this.elRichPanel2.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel2.ContainerStyle.BorderStyle.SmoothingMode = Klik.Windows.Forms.v1.Common.SmoothingModes.AntiAlias;
            this.elRichPanel2.ContainerStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elRichPanel2.Controls.Add(this.txtTedad);
            this.elRichPanel2.Controls.Add(this.txtBookId);
            this.elRichPanel2.Controls.Add(this.label4);
            this.elRichPanel2.Controls.Add(this.label1);
            this.elRichPanel2.Controls.Add(this.button4);
            this.elRichPanel2.Controls.Add(this.button1);
            this.elRichPanel2.Controls.Add(this.label5);
            this.elRichPanel2.Controls.Add(this.label10);
            this.elRichPanel2.Controls.Add(this.txtName);
            this.elRichPanel2.Controls.Add(this.label2);
            this.elRichPanel2.Controls.Add(this.label6);
            this.elRichPanel2.Controls.Add(this.txtAuthor);
            this.elRichPanel2.Controls.Add(this.label3);
            this.elRichPanel2.Controls.Add(this.bt4delete);
            this.elRichPanel2.Controls.Add(this.label8);
            this.elRichPanel2.Controls.Add(this.txtISBN);
            this.elRichPanel2.Controls.Add(this.label7);
            this.elRichPanel2.Controls.Add(this.txtpublisher);
            this.elRichPanel2.Controls.Add(this.txtprice);
            this.elRichPanel2.Controls.Add(this.BTedit);
            this.elRichPanel2.Controls.Add(this.txtradebandi);
            this.elRichPanel2.Controls.Add(this.txtPublishyear);
            this.elRichPanel2.Expanded = true;
            this.elRichPanel2.FooterStyle.BackgroundStyle.GradientAngle = 0F;
            this.elRichPanel2.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel2.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel2.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel2.FooterStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.elRichPanel2.FooterStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elRichPanel2.FooterStyle.TextStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(83)))), ((int)(((byte)(92)))));
            this.elRichPanel2.HeaderStyle.BackgroundImageStyle.FilterColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.elRichPanel2.HeaderStyle.BackgroundStyle.SolidColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.elRichPanel2.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel2.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel2.HeaderStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.elRichPanel2.HeaderStyle.ForegroundImageStyle.TransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.elRichPanel2.HeaderStyle.Height = 24;
            this.elRichPanel2.HeaderStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elRichPanel2.HeaderStyle.TextStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(83)))), ((int)(((byte)(92)))));
            this.elRichPanel2.HeaderStyle.TextStyle.Text = "منوی ورود اطلاعات ";
            this.elRichPanel2.Location = new System.Drawing.Point(545, 12);
            this.elRichPanel2.Name = "elRichPanel2";
            this.elRichPanel2.Padding = new System.Windows.Forms.Padding(1, 24, 1, 16);
            this.elRichPanel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.elRichPanel2.Size = new System.Drawing.Size(341, 340);
            this.elRichPanel2.TabIndex = 65;
            // 
            // txtTedad
            // 
            this.txtTedad.Location = new System.Drawing.Point(134, 289);
            this.txtTedad.Name = "txtTedad";
            this.txtTedad.Size = new System.Drawing.Size(100, 21);
            this.txtTedad.TabIndex = 69;
            // 
            // txtBookId
            // 
            this.txtBookId.Location = new System.Drawing.Point(134, 34);
            this.txtBookId.Name = "txtBookId";
            this.txtBookId.Size = new System.Drawing.Size(100, 21);
            this.txtBookId.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(285, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 13);
            this.label4.TabIndex = 22;
            this.label4.Text = "کد کتاب:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Location = new System.Drawing.Point(296, 291);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(34, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "تعداد:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btback
            // 
            this.btback.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btback.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btback.Location = new System.Drawing.Point(626, 500);
            this.btback.Name = "btback";
            this.btback.Size = new System.Drawing.Size(75, 23);
            this.btback.TabIndex = 66;
            this.btback.Text = "بازگشت";
            this.btback.Click += new System.EventHandler(this.btback_Click);
            // 
            // btExit
            // 
            this.btExit.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btExit.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btExit.Location = new System.Drawing.Point(545, 500);
            this.btExit.Name = "btExit";
            this.btExit.Size = new System.Drawing.Size(75, 23);
            this.btExit.TabIndex = 66;
            this.btExit.Text = "خروج";
            this.btExit.Click += new System.EventHandler(this.btExit_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LightSlateGray;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bookId,
            this.name,
            this.author,
            this.isbn,
            this.publisher,
            this.publishyear,
            this.price,
            this.radebandi,
            this.tedad});
            this.dataGridView1.ContextMenuStrip = this.contextMenuStrip1;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Left;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(483, 529);
            this.dataGridView1.TabIndex = 62;
            this.dataGridView1.TabStop = false;
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.dataGridView1_SelectionChanged);
            // 
            // bookId
            // 
            this.bookId.DataPropertyName = "bookId";
            this.bookId.HeaderText = "کد کتاب ";
            this.bookId.Name = "bookId";
            this.bookId.Width = 70;
            // 
            // name
            // 
            this.name.DataPropertyName = "name";
            this.name.HeaderText = "نام کتاب ";
            this.name.Name = "name";
            this.name.Width = 72;
            // 
            // author
            // 
            this.author.DataPropertyName = "author";
            this.author.HeaderText = "نویسنده";
            this.author.Name = "author";
            this.author.Width = 70;
            // 
            // isbn
            // 
            this.isbn.DataPropertyName = "isbn";
            this.isbn.HeaderText = "شابک";
            this.isbn.Name = "isbn";
            this.isbn.Visible = false;
            this.isbn.Width = 60;
            // 
            // publisher
            // 
            this.publisher.DataPropertyName = "publisher";
            this.publisher.HeaderText = "ناشر";
            this.publisher.Name = "publisher";
            this.publisher.Width = 54;
            // 
            // publishyear
            // 
            this.publishyear.DataPropertyName = "publishyear";
            this.publishyear.HeaderText = "سال چاپ";
            this.publishyear.Name = "publishyear";
            this.publishyear.Width = 75;
            // 
            // price
            // 
            this.price.DataPropertyName = "price";
            this.price.HeaderText = "قیمت";
            this.price.Name = "price";
            this.price.Visible = false;
            this.price.Width = 58;
            // 
            // radebandi
            // 
            this.radebandi.DataPropertyName = "radebandi";
            this.radebandi.HeaderText = "رده بندی کنگره";
            this.radebandi.Name = "radebandi";
            this.radebandi.Visible = false;
            // 
            // tedad
            // 
            this.tedad.DataPropertyName = "tedad";
            this.tedad.HeaderText = "تعداد";
            this.tedad.Name = "tedad";
            this.tedad.Width = 55;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Location = new System.Drawing.Point(816, 505);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 13);
            this.label9.TabIndex = 67;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(735, 500);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 68;
            this.button2.Text = "کل کتب موجود";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // frminsertbook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(902, 529);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btback);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btExit);
            this.Controls.Add(this.elRichPanel1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.elRichPanel2);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frminsertbook";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "منوی ثبت کتاب";
            this.Load += new System.EventHandler(this.frminsertbook_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).EndInit();
            this.elRichPanel1.ResumeLayout(false);
            this.elRichPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel2)).EndInit();
            this.elRichPanel2.ResumeLayout(false);
            this.elRichPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtAuthor;
        private System.Windows.Forms.TextBox txtISBN;
        private System.Windows.Forms.TextBox txtpublisher;
        private System.Windows.Forms.TextBox txtPublishyear;
        private System.Windows.Forms.TextBox txtprice;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtradebandi;
        private System.Windows.Forms.Button BTedit;
        private System.Windows.Forms.Button bt4delete;
        private System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.RadioButton radioBkAuthor;
        public System.Windows.Forms.RadioButton radioBkName;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem حذفToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem بروزرسانیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem خروجToolStripMenuItem;
        private System.Windows.Forms.ToolTip toolTip1;
        public System.Windows.Forms.RadioButton radioBkCode;
        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel1;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel2;
        private DevComponents.DotNetBar.ButtonX btback;
        private DevComponents.DotNetBar.ButtonX btExit;
        private System.Windows.Forms.TextBox txtBookId;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.DataGridView dataGridView1;
        public System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtTedad;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridViewTextBoxColumn bookId;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn author;
        private System.Windows.Forms.DataGridViewTextBoxColumn isbn;
        private System.Windows.Forms.DataGridViewTextBoxColumn publisher;
        private System.Windows.Forms.DataGridViewTextBoxColumn publishyear;
        private System.Windows.Forms.DataGridViewTextBoxColumn price;
        private System.Windows.Forms.DataGridViewTextBoxColumn radebandi;
        private System.Windows.Forms.DataGridViewTextBoxColumn tedad;
    }
}