﻿namespace library
{
    partial class FrmAmanat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.BtDelete = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.txtMemberName = new System.Windows.Forms.TextBox();
            this.txtReturn = new System.Windows.Forms.TextBox();
            this.txtDateSabt = new System.Windows.Forms.TextBox();
            this.txtBookId = new System.Windows.Forms.TextBox();
            this.txtAmanatId = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNameBook = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.elRichPanel2 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.button4 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.farsiDatePicker1 = new FarsiCalendarComponent.FarsiDatePicker();
            this.buttonX1 = new DevComponents.DotNetBar.ButtonX();
            this.BtSabtAmanat = new System.Windows.Forms.Button();
            this.btadd = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtMemberId = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMemberFamily = new System.Windows.Forms.TextBox();
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            this.DatagAmanat = new System.Windows.Forms.DataGridView();
            this.AmanatId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BookId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MemberId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MemberName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Family = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BookName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateSabt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReturnDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.elRichPanel1 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.BtReturn = new System.Windows.Forms.Button();
            this.radioBtMemberId = new System.Windows.Forms.RadioButton();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.radioBtBookName = new System.Windows.Forms.RadioButton();
            this.radioBtFamily = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel2)).BeginInit();
            this.elRichPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DatagAmanat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).BeginInit();
            this.elRichPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(101, 29);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(50, 21);
            this.button1.TabIndex = 0;
            this.button1.Text = "...";
            this.toolTip1.SetToolTip(this.button1, "برای انتخاب کتاب کلیک کنید");
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // BtDelete
            // 
            this.BtDelete.Location = new System.Drawing.Point(4, 272);
            this.BtDelete.Name = "BtDelete";
            this.BtDelete.Size = new System.Drawing.Size(75, 23);
            this.BtDelete.TabIndex = 1;
            this.BtDelete.Text = "حذف ";
            this.BtDelete.UseVisualStyleBackColor = true;
            this.BtDelete.Click += new System.EventHandler(this.BtDelete_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(4, 235);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "ویرایش";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // txtMemberName
            // 
            this.txtMemberName.Enabled = false;
            this.txtMemberName.Location = new System.Drawing.Point(101, 130);
            this.txtMemberName.Name = "txtMemberName";
            this.txtMemberName.Size = new System.Drawing.Size(146, 21);
            this.txtMemberName.TabIndex = 3;
            // 
            // txtReturn
            // 
            this.txtReturn.Enabled = false;
            this.txtReturn.Location = new System.Drawing.Point(101, 239);
            this.txtReturn.Name = "txtReturn";
            this.txtReturn.Size = new System.Drawing.Size(146, 21);
            this.txtReturn.TabIndex = 4;
            this.txtReturn.TextChanged += new System.EventHandler(this.txtReturn_TextChanged);
            // 
            // txtDateSabt
            // 
            this.txtDateSabt.Enabled = false;
            this.txtDateSabt.Location = new System.Drawing.Point(101, 202);
            this.txtDateSabt.Name = "txtDateSabt";
            this.txtDateSabt.Size = new System.Drawing.Size(146, 21);
            this.txtDateSabt.TabIndex = 5;
            this.txtDateSabt.TextChanged += new System.EventHandler(this.txtDateSabt_TextChanged);
            // 
            // txtBookId
            // 
            this.txtBookId.Enabled = false;
            this.txtBookId.Location = new System.Drawing.Point(149, 29);
            this.txtBookId.Name = "txtBookId";
            this.txtBookId.Size = new System.Drawing.Size(98, 21);
            this.txtBookId.TabIndex = 7;
            // 
            // txtAmanatId
            // 
            this.txtAmanatId.Location = new System.Drawing.Point(101, 278);
            this.txtAmanatId.Multiline = true;
            this.txtAmanatId.Name = "txtAmanatId";
            this.txtAmanatId.Size = new System.Drawing.Size(146, 21);
            this.txtAmanatId.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(279, 61);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 13);
            this.label6.TabIndex = 109;
            this.label6.Text = "کد عضویت:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(266, 169);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 13);
            this.label7.TabIndex = 111;
            this.label7.Text = "نام خانوادگی :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(277, 280);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 107;
            this.label1.Text = "شماره ثبت:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(286, 203);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 111;
            this.label2.Text = "تاریخ ثبت:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(266, 243);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 13);
            this.label3.TabIndex = 111;
            this.label3.Text = "تاریخ بازگشت:";
            // 
            // txtNameBook
            // 
            this.txtNameBook.Enabled = false;
            this.txtNameBook.Location = new System.Drawing.Point(101, 92);
            this.txtNameBook.Name = "txtNameBook";
            this.txtNameBook.Size = new System.Drawing.Size(146, 21);
            this.txtNameBook.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(277, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 111;
            this.label4.Text = "عنوان کتاب:";
            // 
            // elRichPanel2
            // 
            this.elRichPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.elRichPanel2.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel2.ContainerStyle.BorderStyle.SmoothingMode = Klik.Windows.Forms.v1.Common.SmoothingModes.AntiAlias;
            this.elRichPanel2.ContainerStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elRichPanel2.Controls.Add(this.button4);
            this.elRichPanel2.Controls.Add(this.button2);
            this.elRichPanel2.Controls.Add(this.farsiDatePicker1);
            this.elRichPanel2.Controls.Add(this.buttonX1);
            this.elRichPanel2.Controls.Add(this.BtSabtAmanat);
            this.elRichPanel2.Controls.Add(this.button1);
            this.elRichPanel2.Controls.Add(this.btadd);
            this.elRichPanel2.Controls.Add(this.txtMemberName);
            this.elRichPanel2.Controls.Add(this.label8);
            this.elRichPanel2.Controls.Add(this.txtNameBook);
            this.elRichPanel2.Controls.Add(this.txtMemberId);
            this.elRichPanel2.Controls.Add(this.label1);
            this.elRichPanel2.Controls.Add(this.label5);
            this.elRichPanel2.Controls.Add(this.label6);
            this.elRichPanel2.Controls.Add(this.label4);
            this.elRichPanel2.Controls.Add(this.BtDelete);
            this.elRichPanel2.Controls.Add(this.label3);
            this.elRichPanel2.Controls.Add(this.button3);
            this.elRichPanel2.Controls.Add(this.label2);
            this.elRichPanel2.Controls.Add(this.label7);
            this.elRichPanel2.Controls.Add(this.txtMemberFamily);
            this.elRichPanel2.Controls.Add(this.txtReturn);
            this.elRichPanel2.Controls.Add(this.txtDateSabt);
            this.elRichPanel2.Controls.Add(this.txtBookId);
            this.elRichPanel2.Controls.Add(this.txtAmanatId);
            this.elRichPanel2.Expanded = true;
            this.elRichPanel2.FooterStyle.BackgroundStyle.GradientAngle = 0F;
            this.elRichPanel2.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel2.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel2.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel2.FooterStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.elRichPanel2.FooterStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elRichPanel2.FooterStyle.TextStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(83)))), ((int)(((byte)(92)))));
            this.elRichPanel2.HeaderStyle.BackgroundImageStyle.FilterColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.elRichPanel2.HeaderStyle.BackgroundStyle.SolidColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.elRichPanel2.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel2.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel2.HeaderStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.elRichPanel2.HeaderStyle.ForegroundImageStyle.TransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.elRichPanel2.HeaderStyle.Height = 24;
            this.elRichPanel2.HeaderStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elRichPanel2.HeaderStyle.TextStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(83)))), ((int)(((byte)(92)))));
            this.elRichPanel2.HeaderStyle.TextStyle.Text = "منوی ورود اطلاعات ";
            this.elRichPanel2.Location = new System.Drawing.Point(712, 12);
            this.elRichPanel2.Name = "elRichPanel2";
            this.elRichPanel2.Padding = new System.Windows.Forms.Padding(1, 24, 1, 16);
            this.elRichPanel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.elRichPanel2.Size = new System.Drawing.Size(345, 350);
            this.elRichPanel2.TabIndex = 118;
            this.elRichPanel2.Click += new System.EventHandler(this.elRichPanel2_Click);
            // 
            // button4
            // 
            this.button4.Enabled = false;
            this.button4.Location = new System.Drawing.Point(4, 235);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 125;
            this.button4.Text = "ثبت تغییرات";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Visible = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(4, 308);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 124;
            this.button2.Text = "جریمه";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // farsiDatePicker1
            // 
            this.farsiDatePicker1.GeoDate = new System.DateTime(2013, 5, 10, 0, 0, 0, 0);
            this.farsiDatePicker1.Location = new System.Drawing.Point(101, 310);
            this.farsiDatePicker1.MaximumSize = new System.Drawing.Size(1000, 21);
            this.farsiDatePicker1.Name = "farsiDatePicker1";
            this.farsiDatePicker1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.farsiDatePicker1.Size = new System.Drawing.Size(146, 21);
            this.farsiDatePicker1.TabIndex = 122;
            // 
            // buttonX1
            // 
            this.buttonX1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX1.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX1.Location = new System.Drawing.Point(101, 239);
            this.buttonX1.Name = "buttonX1";
            this.buttonX1.Size = new System.Drawing.Size(50, 23);
            this.buttonX1.TabIndex = 120;
            this.buttonX1.Text = "...";
            this.buttonX1.Tooltip = "برای تغییر تاریخ کلیک کنید";
            this.buttonX1.Click += new System.EventHandler(this.buttonX1_Click);
            // 
            // BtSabtAmanat
            // 
            this.BtSabtAmanat.Location = new System.Drawing.Point(4, 32);
            this.BtSabtAmanat.Name = "BtSabtAmanat";
            this.BtSabtAmanat.Size = new System.Drawing.Size(75, 23);
            this.BtSabtAmanat.TabIndex = 120;
            this.BtSabtAmanat.Text = "ثبت";
            this.BtSabtAmanat.UseVisualStyleBackColor = true;
            this.BtSabtAmanat.Click += new System.EventHandler(this.BtSabtAmanat_Click);
            // 
            // btadd
            // 
            this.btadd.Location = new System.Drawing.Point(101, 60);
            this.btadd.Name = "btadd";
            this.btadd.Size = new System.Drawing.Size(50, 21);
            this.btadd.TabIndex = 112;
            this.btadd.Text = "...";
            this.toolTip1.SetToolTip(this.btadd, "برای انتخاب عضو کلیک کنید");
            this.btadd.UseVisualStyleBackColor = true;
            this.btadd.Click += new System.EventHandler(this.btadd_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(292, 32);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 13);
            this.label8.TabIndex = 114;
            this.label8.Text = "کد کتاب:";
            // 
            // txtMemberId
            // 
            this.txtMemberId.Enabled = false;
            this.txtMemberId.Location = new System.Drawing.Point(149, 60);
            this.txtMemberId.Name = "txtMemberId";
            this.txtMemberId.Size = new System.Drawing.Size(98, 21);
            this.txtMemberId.TabIndex = 113;
            this.txtMemberId.TextChanged += new System.EventHandler(this.txtMemberId_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(314, 135);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(24, 13);
            this.label5.TabIndex = 109;
            this.label5.Text = "نام:";
            // 
            // txtMemberFamily
            // 
            this.txtMemberFamily.Enabled = false;
            this.txtMemberFamily.Location = new System.Drawing.Point(101, 165);
            this.txtMemberFamily.Name = "txtMemberFamily";
            this.txtMemberFamily.Size = new System.Drawing.Size(146, 21);
            this.txtMemberFamily.TabIndex = 4;
            // 
            // kFormManager1
            // 
            this.kFormManager1.BackgroundImageStyle.Alpha = 100;
            this.kFormManager1.BackgroundImageStyle.ImageEffect = Klik.Windows.Forms.v1.Common.ImageEffect.Mirror;
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.FormOffice2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.kFormManager1.MainContainer = this;
            this.kFormManager1.ToolStripOffice2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            // 
            // DatagAmanat
            // 
            this.DatagAmanat.AllowUserToOrderColumns = true;
            this.DatagAmanat.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.DatagAmanat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DatagAmanat.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.AmanatId,
            this.BookId,
            this.MemberId,
            this.MemberName,
            this.Family,
            this.BookName,
            this.DateSabt,
            this.ReturnDate});
            this.DatagAmanat.Dock = System.Windows.Forms.DockStyle.Left;
            this.DatagAmanat.Location = new System.Drawing.Point(0, 0);
            this.DatagAmanat.MultiSelect = false;
            this.DatagAmanat.Name = "DatagAmanat";
            this.DatagAmanat.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DatagAmanat.Size = new System.Drawing.Size(658, 501);
            this.DatagAmanat.TabIndex = 119;
            this.DatagAmanat.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DatagAmanat_CellContentClick);
            this.DatagAmanat.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DatagAmanat_CellContentClick);
            this.DatagAmanat.SelectionChanged += new System.EventHandler(this.DatagAmanat_SelectionChanged);
            // 
            // AmanatId
            // 
            this.AmanatId.DataPropertyName = "AmanatId";
            this.AmanatId.HeaderText = "کد ثبت";
            this.AmanatId.Name = "AmanatId";
            this.AmanatId.ReadOnly = true;
            this.AmanatId.Width = 63;
            // 
            // BookId
            // 
            this.BookId.DataPropertyName = "BookId";
            this.BookId.HeaderText = "کد کتاب";
            this.BookId.Name = "BookId";
            this.BookId.ReadOnly = true;
            this.BookId.Width = 67;
            // 
            // MemberId
            // 
            this.MemberId.DataPropertyName = "MemberId";
            this.MemberId.HeaderText = "کد عضویت";
            this.MemberId.Name = "MemberId";
            this.MemberId.ReadOnly = true;
            this.MemberId.Width = 80;
            // 
            // MemberName
            // 
            this.MemberName.DataPropertyName = "MemberName";
            this.MemberName.HeaderText = "نام عضو";
            this.MemberName.Name = "MemberName";
            this.MemberName.ReadOnly = true;
            this.MemberName.Width = 69;
            // 
            // Family
            // 
            this.Family.DataPropertyName = "Family";
            this.Family.HeaderText = "نام خانوادگی";
            this.Family.Name = "Family";
            this.Family.ReadOnly = true;
            this.Family.Width = 90;
            // 
            // BookName
            // 
            this.BookName.DataPropertyName = "BookName";
            this.BookName.HeaderText = "نام کتاب";
            this.BookName.Name = "BookName";
            this.BookName.ReadOnly = true;
            this.BookName.Width = 69;
            // 
            // DateSabt
            // 
            this.DateSabt.DataPropertyName = "DateSabt";
            this.DateSabt.HeaderText = "تاریخ ثبت";
            this.DateSabt.Name = "DateSabt";
            this.DateSabt.ReadOnly = true;
            this.DateSabt.Width = 73;
            // 
            // ReturnDate
            // 
            this.ReturnDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ReturnDate.DataPropertyName = "ReturnDate";
            this.ReturnDate.HeaderText = "تاریخ بازگشت";
            this.ReturnDate.Name = "ReturnDate";
            this.ReturnDate.ReadOnly = true;
            // 
            // elRichPanel1
            // 
            this.elRichPanel1.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel1.ContainerStyle.BorderStyle.SmoothingMode = Klik.Windows.Forms.v1.Common.SmoothingModes.AntiAlias;
            this.elRichPanel1.ContainerStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elRichPanel1.Controls.Add(this.BtReturn);
            this.elRichPanel1.Controls.Add(this.radioBtMemberId);
            this.elRichPanel1.Controls.Add(this.txtSearch);
            this.elRichPanel1.Controls.Add(this.radioBtBookName);
            this.elRichPanel1.Controls.Add(this.radioBtFamily);
            this.elRichPanel1.Expanded = true;
            this.elRichPanel1.FooterStyle.BackgroundStyle.GradientAngle = 0F;
            this.elRichPanel1.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel1.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.FooterStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.elRichPanel1.FooterStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elRichPanel1.FooterStyle.TextStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(83)))), ((int)(((byte)(92)))));
            this.elRichPanel1.HeaderStyle.BackgroundImageStyle.FilterColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.elRichPanel1.HeaderStyle.BackgroundStyle.SolidColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.elRichPanel1.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.HeaderStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.elRichPanel1.HeaderStyle.ForegroundImageStyle.TransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.elRichPanel1.HeaderStyle.Height = 24;
            this.elRichPanel1.HeaderStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elRichPanel1.HeaderStyle.TextStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(83)))), ((int)(((byte)(92)))));
            this.elRichPanel1.HeaderStyle.TextStyle.Text = "منوی جستجو ";
            this.elRichPanel1.Location = new System.Drawing.Point(712, 369);
            this.elRichPanel1.Name = "elRichPanel1";
            this.elRichPanel1.Padding = new System.Windows.Forms.Padding(1, 24, 1, 16);
            this.elRichPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.elRichPanel1.Size = new System.Drawing.Size(345, 113);
            this.elRichPanel1.TabIndex = 120;
            // 
            // BtReturn
            // 
            this.BtReturn.Location = new System.Drawing.Point(4, 67);
            this.BtReturn.Name = "BtReturn";
            this.BtReturn.Size = new System.Drawing.Size(158, 23);
            this.BtReturn.TabIndex = 123;
            this.BtReturn.Text = "بازگشت به منوی اصلی";
            this.BtReturn.UseVisualStyleBackColor = true;
            this.BtReturn.Click += new System.EventHandler(this.BtReturn_Click);
            // 
            // radioBtMemberId
            // 
            this.radioBtMemberId.AutoSize = true;
            this.radioBtMemberId.Location = new System.Drawing.Point(209, 27);
            this.radioBtMemberId.Name = "radioBtMemberId";
            this.radioBtMemberId.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioBtMemberId.Size = new System.Drawing.Size(73, 17);
            this.radioBtMemberId.TabIndex = 114;
            this.radioBtMemberId.TabStop = true;
            this.radioBtMemberId.Text = "کد عضویت";
            this.radioBtMemberId.UseVisualStyleBackColor = true;
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(4, 36);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(158, 21);
            this.txtSearch.TabIndex = 10;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // radioBtBookName
            // 
            this.radioBtBookName.AutoSize = true;
            this.radioBtBookName.Location = new System.Drawing.Point(207, 50);
            this.radioBtBookName.Name = "radioBtBookName";
            this.radioBtBookName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioBtBookName.Size = new System.Drawing.Size(75, 17);
            this.radioBtBookName.TabIndex = 114;
            this.radioBtBookName.TabStop = true;
            this.radioBtBookName.Text = "عنوان کتاب";
            this.radioBtBookName.UseVisualStyleBackColor = true;
            // 
            // radioBtFamily
            // 
            this.radioBtFamily.AutoSize = true;
            this.radioBtFamily.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radioBtFamily.Location = new System.Drawing.Point(199, 73);
            this.radioBtFamily.Name = "radioBtFamily";
            this.radioBtFamily.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioBtFamily.Size = new System.Drawing.Size(83, 17);
            this.radioBtFamily.TabIndex = 114;
            this.radioBtFamily.TabStop = true;
            this.radioBtFamily.Text = "نام خانوادگی";
            this.radioBtFamily.UseVisualStyleBackColor = true;
            // 
            // FrmAmanat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1069, 501);
            this.Controls.Add(this.elRichPanel1);
            this.Controls.Add(this.DatagAmanat);
            this.Controls.Add(this.elRichPanel2);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "FrmAmanat";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Text = "فرم ثبت امانات";
            this.Load += new System.EventHandler(this.FrmAmanat_Load);
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel2)).EndInit();
            this.elRichPanel2.ResumeLayout(false);
            this.elRichPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DatagAmanat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).EndInit();
            this.elRichPanel1.ResumeLayout(false);
            this.elRichPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button BtDelete;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox txtMemberName;
        private System.Windows.Forms.TextBox txtReturn;
        private System.Windows.Forms.TextBox txtDateSabt;
        private System.Windows.Forms.TextBox txtBookId;
        private System.Windows.Forms.TextBox txtAmanatId;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNameBook;
        private System.Windows.Forms.Label label4;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel2;
        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private System.Windows.Forms.Button btadd;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtMemberId;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMemberFamily;
        private System.Windows.Forms.DataGridView DatagAmanat;
        private System.Windows.Forms.Button BtSabtAmanat;
        private System.Windows.Forms.DataGridViewTextBoxColumn AmanatId;
        private System.Windows.Forms.DataGridViewTextBoxColumn BookId;
        private System.Windows.Forms.DataGridViewTextBoxColumn MemberId;
        private System.Windows.Forms.DataGridViewTextBoxColumn MemberName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Family;
        private System.Windows.Forms.DataGridViewTextBoxColumn BookName;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateSabt;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReturnDate;
        private DevComponents.DotNetBar.ButtonX buttonX1;
        private System.Windows.Forms.ToolTip toolTip1;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel1;
        private System.Windows.Forms.RadioButton radioBtMemberId;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.RadioButton radioBtBookName;
        private System.Windows.Forms.RadioButton radioBtFamily;
        private FarsiCalendarComponent.FarsiDatePicker farsiDatePicker1;
        private System.Windows.Forms.Button BtReturn;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
    }
}