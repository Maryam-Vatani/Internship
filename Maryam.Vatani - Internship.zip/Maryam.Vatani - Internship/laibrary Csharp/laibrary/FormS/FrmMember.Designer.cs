﻿namespace library
{
    partial class FrmMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtId = new System.Windows.Forms.TextBox();
            this.txtTel = new System.Windows.Forms.TextBox();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.txtfamily = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.MemberId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.family = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btInsert = new System.Windows.Forms.Button();
            this.btDelete = new System.Windows.Forms.Button();
            this.btEdit = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.radioBtName = new System.Windows.Forms.RadioButton();
            this.radioBtFamily = new System.Windows.Forms.RadioButton();
            this.radioBCity = new System.Windows.Forms.RadioButton();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.BtExit = new DevComponents.DotNetBar.ButtonX();
            this.BtBack = new DevComponents.DotNetBar.ButtonX();
            this.elRichPanel2 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.elRichPanel1 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.button2 = new System.Windows.Forms.Button();
            this.labelkol = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel2)).BeginInit();
            this.elRichPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).BeginInit();
            this.elRichPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(249, 82);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 13);
            this.label7.TabIndex = 106;
            this.label7.Text = "نام خانوادگی :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(262, 153);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 13);
            this.label6.TabIndex = 104;
            this.label6.Text = "کد عضویت:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(286, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 103;
            this.label2.Text = "تلفن: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(285, 188);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 105;
            this.label3.Text = "آدرس:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(294, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 102;
            this.label1.Text = "نام: ";
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(131, 149);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(100, 21);
            this.txtId.TabIndex = 4;
            this.txtId.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtId_KeyPress);
            // 
            // txtTel
            // 
            this.txtTel.Location = new System.Drawing.Point(131, 114);
            this.txtTel.Name = "txtTel";
            this.txtTel.Size = new System.Drawing.Size(100, 21);
            this.txtTel.TabIndex = 3;
            this.txtTel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTel_KeyPress);
            // 
            // txtaddress
            // 
            this.txtaddress.Location = new System.Drawing.Point(5, 184);
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(226, 21);
            this.txtaddress.TabIndex = 5;
            // 
            // txtfamily
            // 
            this.txtfamily.Location = new System.Drawing.Point(131, 78);
            this.txtfamily.Name = "txtfamily";
            this.txtfamily.Size = new System.Drawing.Size(100, 21);
            this.txtfamily.TabIndex = 2;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(131, 44);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 21);
            this.txtName.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LightSlateGray;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MemberId,
            this.name,
            this.family,
            this.tel,
            this.address});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Left;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(532, 438);
            this.dataGridView1.TabIndex = 107;
            this.dataGridView1.TabStop = false;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.dataGridView1_SelectionChanged);
            // 
            // MemberId
            // 
            this.MemberId.DataPropertyName = "MemberId";
            this.MemberId.HeaderText = "کد عضویت";
            this.MemberId.Name = "MemberId";
            this.MemberId.ReadOnly = true;
            this.MemberId.Width = 80;
            // 
            // name
            // 
            this.name.DataPropertyName = "name";
            this.name.HeaderText = "نام";
            this.name.Name = "name";
            this.name.ReadOnly = true;
            this.name.Width = 45;
            // 
            // family
            // 
            this.family.DataPropertyName = "family";
            this.family.HeaderText = "نام خانوادگی";
            this.family.Name = "family";
            this.family.ReadOnly = true;
            this.family.Width = 90;
            // 
            // tel
            // 
            this.tel.DataPropertyName = "tel";
            this.tel.HeaderText = "تلفن";
            this.tel.Name = "tel";
            this.tel.ReadOnly = true;
            this.tel.Width = 53;
            // 
            // address
            // 
            this.address.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.address.DataPropertyName = "address";
            this.address.HeaderText = "آدرس";
            this.address.Name = "address";
            this.address.ReadOnly = true;
            // 
            // btInsert
            // 
            this.btInsert.Location = new System.Drawing.Point(5, 44);
            this.btInsert.Name = "btInsert";
            this.btInsert.Size = new System.Drawing.Size(75, 23);
            this.btInsert.TabIndex = 6;
            this.btInsert.Text = "افزودن";
            this.btInsert.UseVisualStyleBackColor = true;
            this.btInsert.Click += new System.EventHandler(this.btInsert_Click);
            // 
            // btDelete
            // 
            this.btDelete.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.btDelete.Location = new System.Drawing.Point(5, 78);
            this.btDelete.Name = "btDelete";
            this.btDelete.Size = new System.Drawing.Size(75, 23);
            this.btDelete.TabIndex = 7;
            this.btDelete.Text = "حذف";
            this.btDelete.UseVisualStyleBackColor = true;
            this.btDelete.Click += new System.EventHandler(this.btDelete_Click);
            // 
            // btEdit
            // 
            this.btEdit.Enabled = false;
            this.btEdit.Location = new System.Drawing.Point(4, 113);
            this.btEdit.Name = "btEdit";
            this.btEdit.Size = new System.Drawing.Size(75, 23);
            this.btEdit.TabIndex = 8;
            this.btEdit.Text = "ثبت تغییرات";
            this.btEdit.UseVisualStyleBackColor = true;
            this.btEdit.Click += new System.EventHandler(this.btEdit_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(5, 53);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(173, 21);
            this.textBox1.TabIndex = 0;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // radioBtName
            // 
            this.radioBtName.AutoSize = true;
            this.radioBtName.Location = new System.Drawing.Point(251, 33);
            this.radioBtName.Name = "radioBtName";
            this.radioBtName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioBtName.Size = new System.Drawing.Size(38, 17);
            this.radioBtName.TabIndex = 114;
            this.radioBtName.TabStop = true;
            this.radioBtName.Text = "نام";
            this.radioBtName.UseVisualStyleBackColor = true;
            this.radioBtName.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioBtFamily
            // 
            this.radioBtFamily.AutoSize = true;
            this.radioBtFamily.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radioBtFamily.Location = new System.Drawing.Point(206, 56);
            this.radioBtFamily.Name = "radioBtFamily";
            this.radioBtFamily.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioBtFamily.Size = new System.Drawing.Size(83, 17);
            this.radioBtFamily.TabIndex = 114;
            this.radioBtFamily.TabStop = true;
            this.radioBtFamily.Text = "نام خانوادگی";
            this.radioBtFamily.UseVisualStyleBackColor = true;
            this.radioBtFamily.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioBCity
            // 
            this.radioBCity.AutoSize = true;
            this.radioBCity.Location = new System.Drawing.Point(242, 77);
            this.radioBCity.Name = "radioBCity";
            this.radioBCity.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioBCity.Size = new System.Drawing.Size(47, 17);
            this.radioBCity.TabIndex = 114;
            this.radioBCity.TabStop = true;
            this.radioBCity.Text = "شهر";
            this.radioBCity.UseVisualStyleBackColor = true;
            this.radioBCity.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(5, 113);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "ویرایش";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // BtExit
            // 
            this.BtExit.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.BtExit.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.BtExit.Location = new System.Drawing.Point(564, 406);
            this.BtExit.Name = "BtExit";
            this.BtExit.Size = new System.Drawing.Size(75, 23);
            this.BtExit.TabIndex = 116;
            this.BtExit.Text = "خروچ";
            this.BtExit.Click += new System.EventHandler(this.BtExit_Click);
            // 
            // BtBack
            // 
            this.BtBack.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.BtBack.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.BtBack.Location = new System.Drawing.Point(645, 406);
            this.BtBack.Name = "BtBack";
            this.BtBack.Size = new System.Drawing.Size(75, 23);
            this.BtBack.TabIndex = 116;
            this.BtBack.Text = "بازگشت";
            this.BtBack.Click += new System.EventHandler(this.BtBack_Click);
            // 
            // elRichPanel2
            // 
            this.elRichPanel2.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel2.ContainerStyle.BorderStyle.SmoothingMode = Klik.Windows.Forms.v1.Common.SmoothingModes.AntiAlias;
            this.elRichPanel2.ContainerStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elRichPanel2.Controls.Add(this.button1);
            this.elRichPanel2.Controls.Add(this.btInsert);
            this.elRichPanel2.Controls.Add(this.txtName);
            this.elRichPanel2.Controls.Add(this.txtaddress);
            this.elRichPanel2.Controls.Add(this.label3);
            this.elRichPanel2.Controls.Add(this.txtTel);
            this.elRichPanel2.Controls.Add(this.label2);
            this.elRichPanel2.Controls.Add(this.txtId);
            this.elRichPanel2.Controls.Add(this.label6);
            this.elRichPanel2.Controls.Add(this.label7);
            this.elRichPanel2.Controls.Add(this.btEdit);
            this.elRichPanel2.Controls.Add(this.label1);
            this.elRichPanel2.Controls.Add(this.txtfamily);
            this.elRichPanel2.Controls.Add(this.btDelete);
            this.elRichPanel2.Expanded = true;
            this.elRichPanel2.FooterStyle.BackgroundStyle.GradientAngle = 0F;
            this.elRichPanel2.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel2.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel2.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel2.FooterStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.elRichPanel2.FooterStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elRichPanel2.FooterStyle.TextStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(83)))), ((int)(((byte)(92)))));
            this.elRichPanel2.HeaderStyle.BackgroundImageStyle.FilterColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.elRichPanel2.HeaderStyle.BackgroundStyle.SolidColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.elRichPanel2.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel2.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel2.HeaderStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.elRichPanel2.HeaderStyle.ForegroundImageStyle.TransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.elRichPanel2.HeaderStyle.Height = 24;
            this.elRichPanel2.HeaderStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elRichPanel2.HeaderStyle.TextStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(83)))), ((int)(((byte)(92)))));
            this.elRichPanel2.HeaderStyle.TextStyle.Text = "منوی ورود اطلاعات ";
            this.elRichPanel2.Location = new System.Drawing.Point(559, 12);
            this.elRichPanel2.Name = "elRichPanel2";
            this.elRichPanel2.Padding = new System.Windows.Forms.Padding(1, 24, 1, 16);
            this.elRichPanel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.elRichPanel2.Size = new System.Drawing.Size(341, 253);
            this.elRichPanel2.TabIndex = 117;
            // 
            // elRichPanel1
            // 
            this.elRichPanel1.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel1.ContainerStyle.BorderStyle.SmoothingMode = Klik.Windows.Forms.v1.Common.SmoothingModes.AntiAlias;
            this.elRichPanel1.ContainerStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elRichPanel1.Controls.Add(this.radioBCity);
            this.elRichPanel1.Controls.Add(this.textBox1);
            this.elRichPanel1.Controls.Add(this.radioBtName);
            this.elRichPanel1.Controls.Add(this.radioBtFamily);
            this.elRichPanel1.Expanded = true;
            this.elRichPanel1.FooterStyle.BackgroundStyle.GradientAngle = 0F;
            this.elRichPanel1.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel1.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.FooterStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.elRichPanel1.FooterStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elRichPanel1.FooterStyle.TextStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(83)))), ((int)(((byte)(92)))));
            this.elRichPanel1.HeaderStyle.BackgroundImageStyle.FilterColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.elRichPanel1.HeaderStyle.BackgroundStyle.SolidColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.elRichPanel1.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.HeaderStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.elRichPanel1.HeaderStyle.ForegroundImageStyle.TransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.elRichPanel1.HeaderStyle.Height = 24;
            this.elRichPanel1.HeaderStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elRichPanel1.HeaderStyle.TextStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(83)))), ((int)(((byte)(92)))));
            this.elRichPanel1.HeaderStyle.TextStyle.Text = "منوی جستجو ";
            this.elRichPanel1.Location = new System.Drawing.Point(559, 273);
            this.elRichPanel1.Name = "elRichPanel1";
            this.elRichPanel1.Padding = new System.Windows.Forms.Padding(1, 24, 1, 16);
            this.elRichPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.elRichPanel1.Size = new System.Drawing.Size(341, 127);
            this.elRichPanel1.TabIndex = 118;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(726, 406);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(114, 23);
            this.button2.TabIndex = 120;
            this.button2.Text = "تعداد کل اعضاء";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // labelkol
            // 
            this.labelkol.AutoSize = true;
            this.labelkol.BackColor = System.Drawing.Color.Transparent;
            this.labelkol.Location = new System.Drawing.Point(846, 411);
            this.labelkol.Name = "labelkol";
            this.labelkol.Size = new System.Drawing.Size(0, 13);
            this.labelkol.TabIndex = 119;
            // 
            // FrmMember
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(920, 438);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.labelkol);
            this.Controls.Add(this.elRichPanel1);
            this.Controls.Add(this.elRichPanel2);
            this.Controls.Add(this.BtBack);
            this.Controls.Add(this.BtExit);
            this.Controls.Add(this.dataGridView1);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.Name = "FrmMember";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "مدیریت اعضاء";
            this.Load += new System.EventHandler(this.FrmMember_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel2)).EndInit();
            this.elRichPanel2.ResumeLayout(false);
            this.elRichPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).EndInit();
            this.elRichPanel1.ResumeLayout(false);
            this.elRichPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.TextBox txtTel;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.TextBox txtfamily;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Button btDelete;
        private System.Windows.Forms.Button btEdit;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.RadioButton radioBtName;
        private System.Windows.Forms.RadioButton radioBtFamily;
        private System.Windows.Forms.RadioButton radioBCity;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button button1;
        public System.Windows.Forms.DataGridView dataGridView1;
        private DevComponents.DotNetBar.ButtonX BtExit;
        private DevComponents.DotNetBar.ButtonX BtBack;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel2;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel1;
        public System.Windows.Forms.Button btInsert;
        private System.Windows.Forms.DataGridViewTextBoxColumn MemberId;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn family;
        private System.Windows.Forms.DataGridViewTextBoxColumn tel;
        private System.Windows.Forms.DataGridViewTextBoxColumn address;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label labelkol;
    }
}