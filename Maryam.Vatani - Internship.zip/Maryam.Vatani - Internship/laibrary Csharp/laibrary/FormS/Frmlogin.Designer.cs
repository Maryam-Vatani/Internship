﻿namespace library
{
    partial class FrmUserPass
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevComponents.DotNetBar.Keyboard.VirtualKeyboardColorTable virtualKeyboardColorTable4 = new DevComponents.DotNetBar.Keyboard.VirtualKeyboardColorTable();
            DevComponents.DotNetBar.Keyboard.FlatStyleRenderer flatStyleRenderer4 = new DevComponents.DotNetBar.Keyboard.FlatStyleRenderer();
            this.txtPass = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.BtEnter = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.touchKeyboard1 = new DevComponents.DotNetBar.Keyboard.TouchKeyboard();
            this.elButton1 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.txtName = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.keyboardControl2 = new DevComponents.DotNetBar.Keyboard.KeyboardControl();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.elButton2 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.BtEnter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton2)).BeginInit();
            this.SuspendLayout();
            // 
            // txtPass
            // 
            // 
            // 
            // 
            this.txtPass.Border.Class = "TextBoxBorder";
            this.txtPass.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtPass.Location = new System.Drawing.Point(231, 11);
            this.txtPass.Name = "txtPass";
            this.txtPass.Size = new System.Drawing.Size(163, 21);
            this.txtPass.TabIndex = 2;
            this.toolTip1.SetToolTip(this.txtPass, "رمز ورود");
            this.txtPass.UseSystemPasswordChar = true;
            this.txtPass.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPass_KeyDown);
            // 
            // BtEnter
            // 
            this.BtEnter.BorderStyle.EdgeRadius = 7;
            this.BtEnter.BorderStyle.SmoothingMode = Klik.Windows.Forms.v1.Common.SmoothingModes.AntiAlias;
            this.BtEnter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtEnter.DropDownArrowColor = System.Drawing.Color.Transparent;
            this.BtEnter.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.BtEnter.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.BtEnter.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.BtEnter.Location = new System.Drawing.Point(165, 12);
            this.BtEnter.Name = "BtEnter";
            this.BtEnter.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.BtEnter.Size = new System.Drawing.Size(60, 21);
            this.BtEnter.TabIndex = 8;
            this.BtEnter.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtEnter.TextStyle.ForeColor = System.Drawing.Color.White;
            this.BtEnter.TextStyle.Text = "ورود";
            this.BtEnter.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.BtEnter, "ورود به سیستم کتابخانه");
            this.BtEnter.VisualStyle = Klik.Windows.Forms.v1.EntryLib.ButtonVisualStyles.ToolBar;
            this.BtEnter.Click += new System.EventHandler(this.BtEnter_Click);
            // 
            // touchKeyboard1
            // 
            this.touchKeyboard1.FloatingLocation = new System.Drawing.Point(0, 0);
            this.touchKeyboard1.FloatingSize = new System.Drawing.Size(740, 250);
            this.touchKeyboard1.Location = new System.Drawing.Point(0, 0);
            this.touchKeyboard1.Size = new System.Drawing.Size(740, 250);
            this.touchKeyboard1.Text = "";
            // 
            // elButton1
            // 
            this.elButton1.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.elButton1.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.elButton1.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.elButton1.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.elButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.elButton1.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elButton1.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elButton1.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.elButton1.Location = new System.Drawing.Point(110, 11);
            this.elButton1.Name = "elButton1";
            this.elButton1.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elButton1.Size = new System.Drawing.Size(53, 21);
            this.elButton1.StateStyles.FocusStyle.BackgroundGradientEndColor = System.Drawing.Color.Red;
            this.elButton1.StateStyles.FocusStyle.BackgroundGradientStartColor = System.Drawing.Color.Yellow;
            this.elButton1.TabIndex = 11;
            this.elButton1.TextStyle.BackColor = System.Drawing.SystemColors.InfoText;
            this.elButton1.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elButton1.TextStyle.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.elButton1.TextStyle.GlowColorAlpha = 10;
            this.elButton1.TextStyle.ShadowOffset = new System.Drawing.Point(0, 8);
            this.elButton1.TextStyle.Text = "خروج";
            this.elButton1.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.elButton1.TextStyle.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.elButton1.TextStyle.TextType = Klik.Windows.Forms.v1.Common.TextTypes.Glow;
            this.toolTip1.SetToolTip(this.elButton1, "خروج ");
            this.elButton1.VisualStyle = Klik.Windows.Forms.v1.EntryLib.ButtonVisualStyles.ToolBar;
            this.elButton1.Click += new System.EventHandler(this.elButton1_Click_1);
            // 
            // txtName
            // 
            // 
            // 
            // 
            this.txtName.Border.Class = "TextBoxBorder";
            this.txtName.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtName.Location = new System.Drawing.Point(440, 11);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(160, 21);
            this.txtName.TabIndex = 1;
            this.toolTip1.SetToolTip(this.txtName, "نام کاربری");
            this.txtName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtName_KeyDown);
            // 
            // timer1
            // 
            this.timer1.Interval = 20;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // keyboardControl2
            // 
            this.keyboardControl2.BackColor = System.Drawing.Color.Black;
            virtualKeyboardColorTable4.BackgroundColor = System.Drawing.Color.Black;
            virtualKeyboardColorTable4.DarkKeysColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(28)))), ((int)(((byte)(33)))));
            virtualKeyboardColorTable4.DownKeysColor = System.Drawing.Color.White;
            virtualKeyboardColorTable4.DownTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            virtualKeyboardColorTable4.KeysColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(47)))), ((int)(((byte)(55)))));
            virtualKeyboardColorTable4.LightKeysColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(68)))), ((int)(((byte)(76)))));
            virtualKeyboardColorTable4.PressedKeysColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(161)))), ((int)(((byte)(81)))));
            virtualKeyboardColorTable4.TextColor = System.Drawing.Color.White;
            virtualKeyboardColorTable4.ToggleTextColor = System.Drawing.Color.Green;
            virtualKeyboardColorTable4.TopBarTextColor = System.Drawing.Color.White;
            this.keyboardControl2.ColorTable = virtualKeyboardColorTable4;
            this.keyboardControl2.Location = new System.Drawing.Point(13, 29);
            this.keyboardControl2.Name = "keyboardControl2";
            flatStyleRenderer4.ColorTable = virtualKeyboardColorTable4;
            flatStyleRenderer4.ForceAntiAlias = false;
            this.keyboardControl2.Renderer = flatStyleRenderer4;
            this.keyboardControl2.Size = new System.Drawing.Size(647, 241);
            this.keyboardControl2.TabIndex = 12;
            this.keyboardControl2.Click += new System.EventHandler(this.keyboardControl2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(400, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "رمز";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(606, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "نام کاربری";
            // 
            // elButton2
            // 
            this.elButton2.BorderStyle.EdgeRadius = 7;
            this.elButton2.BorderStyle.SmoothingMode = Klik.Windows.Forms.v1.Common.SmoothingModes.AntiAlias;
            this.elButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.elButton2.DropDownArrowColor = System.Drawing.Color.Transparent;
            this.elButton2.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elButton2.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elButton2.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.elButton2.Location = new System.Drawing.Point(12, 11);
            this.elButton2.Name = "elButton2";
            this.elButton2.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elButton2.Size = new System.Drawing.Size(79, 21);
            this.elButton2.TabIndex = 15;
            this.elButton2.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elButton2.TextStyle.ForeColor = System.Drawing.Color.White;
            this.elButton2.TextStyle.Text = "کیبورد مجازی";
            this.elButton2.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.elButton2, "ورود به سیستم کتابخانه");
            this.elButton2.VisualStyle = Klik.Windows.Forms.v1.EntryLib.ButtonVisualStyles.ToolBar;
            this.elButton2.Click += new System.EventHandler(this.elButton2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(624, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(624, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "label4";
            // 
            // FrmUserPass
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(670, 45);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.elButton2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtEnter);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.elButton1);
            this.Controls.Add(this.txtPass);
            this.Controls.Add(this.keyboardControl2);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmUserPass";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "login";
            this.Load += new System.EventHandler(this.FrmUserPass_Load);
            ((System.ComponentModel.ISupportInitialize)(this.BtEnter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevComponents.DotNetBar.Controls.TextBoxX txtPass;
        private Klik.Windows.Forms.v1.EntryLib.ELButton BtEnter;
        private DevComponents.DotNetBar.Keyboard.TouchKeyboard touchKeyboard1;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton1;
        private System.Windows.Forms.ToolTip toolTip1;
        private DevComponents.DotNetBar.Controls.TextBoxX txtName;
        private System.Windows.Forms.Timer timer1;
        public DevComponents.DotNetBar.Keyboard.KeyboardControl keyboardControl2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}