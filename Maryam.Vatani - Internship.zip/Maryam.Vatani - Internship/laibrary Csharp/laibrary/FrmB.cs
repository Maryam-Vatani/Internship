﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace library
{
    public partial class FrmB : frmTemplates
    {
        public FrmB()
        {
            InitializeComponent();
        }

        private void FrmB_Load(object sender, EventArgs e)
        {
            book b1 = new book();
            dataGridView1.DataSource = b1.show();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (int.Parse(dataGridView1["tedad", dataGridView1.CurrentRow.Index].Value.ToString()) == 0)
            {

                MessageBox.Show("کلیه موجودی این کتاب امانت داده شده است");
            }
            else
            {

                this.Close();
            }
        }
    }
}
