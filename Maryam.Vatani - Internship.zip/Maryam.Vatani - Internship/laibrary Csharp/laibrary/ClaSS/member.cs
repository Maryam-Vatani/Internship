﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;


namespace library
{
    public class member
    {
        public int MemberId;
        public string name;
        public string family;
        public Int64 tel;
        public string address;
        public int m;

        public void Insert()
        {
            DataAccess me = new DataAccess();
            me.Connect();

            OleDbCommand com = new OleDbCommand();
            com.CommandText = "insert into member(MemberId,name,family,tel,address)values(@MemberId,@name,@family,@tel,@address)";
            com.Parameters.AddWithValue("@MemberId", MemberId);
            com.Parameters.AddWithValue("@name", name);
            com.Parameters.AddWithValue("@family", family);
            com.Parameters.AddWithValue("@tel", tel);
            com.Parameters.AddWithValue("@address", address);
            me.Command(com);

            me.Disconnect();
        }

        public DataTable show()
        {
            var da = new DataAccess();
            da.Connect();
            var com = new OleDbCommand();
            com.CommandText = "select * from member";
            var dt = da.Docommand(com);
            da.Disconnect();
            return dt;

        }
        public void Delete()
        {
            var da = new DataAccess();
            da.Connect();
            var com = new OleDbCommand();
            com.CommandText = "delete from member where MemberId=@MemberId";
            com.Parameters.AddWithValue("@MemberId", MemberId);
            da.Command(com);
            da.Disconnect();
        }

        public void Update()
        {
            var da = new DataAccess();
            da.Connect();
            var com = new OleDbCommand();
            com.CommandText = "update member set MemberId=@MemberId, name=@name, family=@family, tel=@tel, address=@address where MemberId=@MemberId";
            com.Parameters.AddWithValue("@MemberId", MemberId);
            com.Parameters.AddWithValue("@name", name);
            com.Parameters.AddWithValue("@family", family);
            com.Parameters.AddWithValue("@tel", tel);
            com.Parameters.AddWithValue("@address", address);
            da.Command(com);


        }

          public DataTable search()
        {
            var da = new DataAccess();
            da.Connect();
            var com = new OleDbCommand();
            if (m == 1)
            {
                com.CommandText = "select * from member where name like @name";
                com.Parameters.AddWithValue("@name", "%" + name + "%");
            }
            else if (m == 2)
 
            {
                com.CommandText = "select * from member where family like @family";
                com.Parameters.AddWithValue("@family", "%" + family  + "%");
            }
            else if (m == 3)
            {
                com.CommandText = "select * from member where address like @address";
                com.Parameters.AddWithValue("@address", "%" + address + "%");
            }
            var dt = da.Docommand(com);
            da.Disconnect();
            return dt;


        }


    }
}

