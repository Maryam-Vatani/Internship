﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;
namespace library
{
    public class book
    {
  
        public int bookId;
        public string name;
        public string author;
        public string isbn;
        public string publisher;
        public string publishyear;
        public string price;
        public string radebandi;
        public int tedad;

        public int b;
        public bool tc;



        /// <summary>
        /// ها کتاب  جدول در درج  
        /// </summary>
        public void Insert()
        {
            DataAccess da = new DataAccess();
            da.Connect();
            if (tc == false)
            {


                OleDbCommand com = new OleDbCommand();
                com.CommandText = "insert into book(bookId,name,author,isbn,publisher,publishyear,price,radebandi,tedad)values(@bookId,@name,@author,@isbn,@publisher,@publishyear,@price,@radebandi,@tedad)";
                com.Parameters.AddWithValue("@bookId", bookId);
                com.Parameters.AddWithValue("@name", name);
                com.Parameters.AddWithValue("@author", author);
                com.Parameters.AddWithValue("@isbn", isbn);
                com.Parameters.AddWithValue("@publisher", publisher);
                com.Parameters.AddWithValue("@publishyear", publishyear);
                com.Parameters.AddWithValue("@price", price);
                com.Parameters.AddWithValue("@radebandi", radebandi);
                com.Parameters.AddWithValue("@tedad", tedad);
                da.Command(com);
            }
            else if (tc == true)
            {
                OleDbCommand com2 = new OleDbCommand();
                com2.CommandText = "update book set tedad = tedad +@tedat where bookId=@bookId ";
                com2.Parameters.AddWithValue("@tedad", tedad);
                com2.Parameters.AddWithValue("@bookId", bookId);
                da.Command(com2);
            }
            da.Disconnect();

        }

        public DataTable show()
        {
            var da = new DataAccess();
            da.Connect();
            var com = new OleDbCommand();
            com.CommandText = "select * from book";
            var dt = da.Docommand(com);
            da.Disconnect();
            return dt;
        }

        public DataTable search()
        {
            var da = new DataAccess();
            da.Connect();
            var com = new OleDbCommand();
            if (b == 1)
            {
                com.CommandText = "select * from book where bookId like @bookId";
                com.Parameters.AddWithValue("@bookId", "%" + bookId + "%"); 
            }
            else if (b == 2)
            {
                com.CommandText = "select * from book where name like @name";

                com.Parameters.AddWithValue("@name", "%" + name + "%");
            }

            else if (b == 3)
            {
                com.CommandText = "select * from book where author like @author";
                com.Parameters.AddWithValue("@author", "%" + author + "%");
            }
                var dt = da.Docommand(com);
            da.Disconnect();
            return dt;
        }
        public void Update()
        {
            var da = new DataAccess();
            da.Connect();
            var com = new OleDbCommand();
            com.CommandText = "update book set name=@name, author=@author, isbn=@isbn, publisher=@publisher, publishyear=@publishyear, price=@price ,radebandi=@radebandi ,tedad=@tedad where bookId=@bookId";
            com.Parameters.AddWithValue("@name", name);
            com.Parameters.AddWithValue("@author", author);
            com.Parameters.AddWithValue("@isbn", isbn);
            com.Parameters.AddWithValue("@publisher", publisher);
            com.Parameters.AddWithValue("@publishyear", publishyear);
            com.Parameters.AddWithValue("@price", price);
            com.Parameters.AddWithValue("@radebandi", radebandi);
            com.Parameters.AddWithValue("@tedad", tedad);
            com.Parameters.AddWithValue("@bookId", bookId);
           
            da.Command(com);
            da.Disconnect();
        } 
         public void Delete()
        {
            var da = new DataAccess();
            da.Connect();
            var com = new OleDbCommand();
            com.CommandText = "delete from book where bookId=@bookId";
            com.Parameters.AddWithValue("@bookId", bookId);
            da.Command(com);
            da.Disconnect();
         }
         public bool Exist()
         {
             OleDbCommand com = new OleDbCommand();
             com.CommandText = "select * from book where bookId=@bookId";
             com.Parameters.AddWithValue("@bookId", bookId);
             var da = new DataAccess();
             da.Connect();
             var dt = da.Docommand(com);
             da.Disconnect();
             if (dt.Rows.Count > 0) return true;
             return false;
         }
    }
}
