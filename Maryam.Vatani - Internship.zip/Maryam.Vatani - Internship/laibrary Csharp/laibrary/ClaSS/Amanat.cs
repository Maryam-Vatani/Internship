﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;


namespace library
{
    public class Amanat
    {
        public int AmanatId;
        public string DateSabt;
        public string ReturnDate;
        public int bookId;
        public int MemberId;
        public string BookName;
        public string MemberName;
        public string Family;
        public int a;

        /// <summary>
        /// امانت جدول در درج
        /// </summary>
        public void Insert()
        {
            DataAccess da = new DataAccess();
            da.Connect();

            OleDbCommand com = new OleDbCommand();
            com.CommandText = "insert into amanat(bookId,MemberId,BookName,MemberName,Family,DateSabt,ReturnDate,AmanatId)values(@bookId,@MemberId,@BookName,@MemberName,@Family,@DateSabt,@ReturnDate,@AmanatId)";
            com.Parameters.AddWithValue("@bookId", bookId);
            com.Parameters.AddWithValue("@MemberId", MemberId);
            com.Parameters.AddWithValue("@BookName", BookName);
            com.Parameters.AddWithValue("@MemberName", MemberName);
            com.Parameters.AddWithValue("@Family", Family);
            com.Parameters.AddWithValue("@DateSabt", DateSabt);
            com.Parameters.AddWithValue("@ReturnDate", ReturnDate);
            com.Parameters.AddWithValue("@AmanatId", AmanatId);
            da.Command(com);
            da.Disconnect();
        }


        public DataTable show()
        {
            var da = new DataAccess();
            da.Connect();
            var com = new OleDbCommand();
            com.CommandText = "select * from amanat";
            var dt = da.Docommand(com);
            da.Disconnect();
            return dt;
        }
        public void Delete()
        {
            var da = new DataAccess();
            da.Connect();
            var com = new OleDbCommand();
            com.CommandText = "delete from Amanat where AmanatId=@AmanatId";
            com.Parameters.AddWithValue("@AmanatId", AmanatId);
            da.Command(com);
            da.Disconnect();
        }

        public void Update()
        {
            var da = new DataAccess();
            da.Connect();
            var com = new OleDbCommand();
            com.CommandText = "update Amanat  set ReturnDate=@ReturnDate where AmanatId=@AmanatId ";

           // com.Parameters.AddWithValue("@bookId", bookId);
          //  com.Parameters.AddWithValue("@MemberId", MemberId);
            //com.Parameters.AddWithValue("@BookName", BookName);
            //com.Parameters.AddWithValue("@MemberName", MemberName);
            //com.Parameters.AddWithValue("@Family", Family);
            //com.Parameters.AddWithValue("@DateSabt", DateSabt);
            com.Parameters.AddWithValue("@ReturnDate", ReturnDate);
            com.Parameters.AddWithValue("@AmanatId", AmanatId);
            da.Command(com);
            da.Disconnect();
        }

        public DataTable search()
        {
            var da = new DataAccess();
            da.Connect();
            var com = new OleDbCommand();
            if (a == 1)
            {
                com.CommandText = "select * from amanat where MemberId like @MemberId";
                com.Parameters.AddWithValue("@MemberId", "%" + MemberId + "%");
            }
            else if (a == 2)
            {
                com.CommandText = "select * from amanat where BookName like @BookName";

                com.Parameters.AddWithValue("@BookName", "%" + BookName + "%");
            }

            else if (a == 3)
            {
                com.CommandText = "select * from amanat where Family like @Family";
                com.Parameters.AddWithValue("@Family", "%" + Family + "%");
            }
            var dt = da.Docommand(com);
            da.Disconnect();
            return dt;
        }
    }
}


