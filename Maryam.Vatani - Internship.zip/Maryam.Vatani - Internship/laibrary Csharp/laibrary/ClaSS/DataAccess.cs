﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;


namespace library
{
    public class DataAccess
    {
    
        OleDbConnection con = new OleDbConnection();
        public void Connect()
        {
            con.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\library.accdb";
            if (con.State == ConnectionState.Closed) con.Open();
        }

        public void Disconnect()
        {
            if (con.State == ConnectionState.Open) con.Close();
        }

        public DataTable Docommand(OleDbCommand com)
        {
            com.Connection = con;
            var da = new OleDbDataAdapter(com);
            com.CommandType = CommandType.Text;
            var dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public void Command(OleDbCommand com)
        {
            com.Connection = con;
            com.CommandType = CommandType.Text;
            com.ExecuteNonQuery();

        }
    }
}
