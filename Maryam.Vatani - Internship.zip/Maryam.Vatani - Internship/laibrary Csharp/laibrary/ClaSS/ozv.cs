﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;


namespace laibrary.ClaSS
{
    public class ozv
    {
        public Int64 id;
        public string name;
        public string family;
        public Int64 tel;
        public string address;

        public void Insert()
        {
            DataAccess da = new DataAccess();
            da.Connect();

            OleDbCommand com = new OleDbCommand();
            com.CommandText = "insert into book(id,name,family,tel,address)values(@id,@name,@family,@tel,@address)";
            com.Parameters.AddWithValue("@id", id);
            com.Parameters.AddWithValue("@name", name);
            com.Parameters.AddWithValue("@family", family);
            com.Parameters.AddWithValue("@tel", tel);
            com.Parameters.AddWithValue("@address", address);

            da.Command(com);
            da.Disconnect();
        }

    }
}
