﻿namespace library
{
    partial class FrmAmanatNew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DateSabt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DatagAmanat = new System.Windows.Forms.DataGridView();
            this.AmanatId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BookId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MemberId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MemberName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Family = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BookName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReturnDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DatagAmanat)).BeginInit();
            this.SuspendLayout();
            // 
            // DateSabt
            // 
            this.DateSabt.DataPropertyName = "DateSabt";
            this.DateSabt.HeaderText = "تاریخ ثبت";
            this.DateSabt.Name = "DateSabt";
            this.DateSabt.Width = 73;
            // 
            // DatagAmanat
            // 
            this.DatagAmanat.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.DatagAmanat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DatagAmanat.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.AmanatId,
            this.BookId,
            this.MemberId,
            this.MemberName,
            this.Family,
            this.BookName,
            this.DateSabt,
            this.ReturnDate});
            this.DatagAmanat.Dock = System.Windows.Forms.DockStyle.Left;
            this.DatagAmanat.Location = new System.Drawing.Point(0, 0);
            this.DatagAmanat.MultiSelect = false;
            this.DatagAmanat.Name = "DatagAmanat";
            this.DatagAmanat.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DatagAmanat.Size = new System.Drawing.Size(717, 443);
            this.DatagAmanat.TabIndex = 123;
            // 
            // AmanatId
            // 
            this.AmanatId.DataPropertyName = "AmanatId";
            this.AmanatId.HeaderText = "کد ثبت";
            this.AmanatId.Name = "AmanatId";
            this.AmanatId.Width = 63;
            // 
            // BookId
            // 
            this.BookId.DataPropertyName = "BookId";
            this.BookId.HeaderText = "کد کتاب";
            this.BookId.Name = "BookId";
            this.BookId.Width = 67;
            // 
            // MemberId
            // 
            this.MemberId.DataPropertyName = "MemberId";
            this.MemberId.HeaderText = "کد عضویت";
            this.MemberId.Name = "MemberId";
            this.MemberId.Width = 80;
            // 
            // MemberName
            // 
            this.MemberName.DataPropertyName = "MemberName";
            this.MemberName.HeaderText = "نام عضو";
            this.MemberName.Name = "MemberName";
            this.MemberName.Width = 69;
            // 
            // Family
            // 
            this.Family.DataPropertyName = "Family";
            this.Family.HeaderText = "نام خانوادگی";
            this.Family.Name = "Family";
            this.Family.Width = 90;
            // 
            // BookName
            // 
            this.BookName.DataPropertyName = "BookName";
            this.BookName.HeaderText = "نام کتاب";
            this.BookName.Name = "BookName";
            this.BookName.Width = 69;
            // 
            // ReturnDate
            // 
            this.ReturnDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ReturnDate.DataPropertyName = "ReturnDate";
            this.ReturnDate.HeaderText = "تاریخ بازگشت";
            this.ReturnDate.Name = "ReturnDate";
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(734, 39);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(164, 23);
            this.button1.TabIndex = 124;
            this.button1.Text = "گزارش";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(781, 12);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(58, 21);
            this.txtSearch.TabIndex = 125;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Location = new System.Drawing.Point(842, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 13);
            this.label6.TabIndex = 126;
            this.label6.Text = "کد عضویت:";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(734, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(41, 21);
            this.button2.TabIndex = 127;
            this.button2.Text = "...";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // FrmAmanatNew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(913, 443);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.DatagAmanat);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtSearch);
            this.Location = new System.Drawing.Point(0, 0);
            this.Name = "FrmAmanatNew";
            this.Text = "FrmAmanatNew";
            this.Load += new System.EventHandler(this.FrmAmanatNew_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DatagAmanat)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridViewTextBoxColumn DateSabt;
        private System.Windows.Forms.DataGridViewTextBoxColumn AmanatId;
        private System.Windows.Forms.DataGridViewTextBoxColumn BookId;
        private System.Windows.Forms.DataGridViewTextBoxColumn MemberId;
        private System.Windows.Forms.DataGridViewTextBoxColumn MemberName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Family;
        private System.Windows.Forms.DataGridViewTextBoxColumn BookName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReturnDate;
        public System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.Button button2;
        public System.Windows.Forms.DataGridView DatagAmanat;
        public System.Windows.Forms.TextBox txtSearch;
    }
}