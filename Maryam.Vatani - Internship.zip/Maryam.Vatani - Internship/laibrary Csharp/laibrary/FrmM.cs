﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace library
{
    public partial class FrmM : frmTemplates
    {
        public FrmM()
        {
            InitializeComponent();
        }

        private void FrmMB_Load(object sender, EventArgs e)
        {
            member m1 = new member();
            dataGridView1.DataSource = m1.show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            this.Close();


        }

        private void elRichPanel2_Click(object sender, EventArgs e)
        {

        }

        private void btInsert_Click(object sender, EventArgs e)
        {
          

            
            
        }

        private void txtfamily_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
           
        }
    }
}
