﻿namespace library {
    
    
    public partial class db1DataSet {
    }
}
